# The Storio Template Manifest Guide

Every template in the Storio CMS ecosystem **must** include a manifest file named `storio.template.json` in its `public/` directory (`public/storio.template.json`).

This document explains the purpose of the manifest, top-level schema rules, how the CMS Template Customizer parses it, how to sync it to your backend with `npm run sync`, and provides the complete JSON structure used in *Emerald Campus*.

---

## Table of Contents

1. [How it Connects to the Template Customizer](#1-how-it-connects-to-the-template-customizer)
2. [Syncing the Manifest to the Backend (`npm run sync`)](#2-syncing-the-manifest-to-the-backend-npm-run-sync)
3. [Critical Top-Level Rules (`id` and `internal_proxy_url`)](#3-critical-top-level-rules-id-and-internal_proxy_url)
4. [Rules for Writing the `customization` Schema](#4-rules-for-writing-the-customization-schema)
5. [Full JSON Structure (Emerald Campus Blueprint)](#5-full-json-structure-emerald-campus-blueprint)
6. [Consuming Manifest Data in Code (`fetchers.ts`)](#6-consuming-manifest-data-in-code-fetchersts)
7. [Build and Run Commands](#7-build-and-run-commands)

---

## 1. How it Connects to the Template Customizer

The manifest is the **single source of truth** for your template's design controls. It bridges your Next.js template and the Storio CMS Dashboard.

1. **Auto-Generated Admin UI:** When an administrator clicks *"Customize Template"* in the Storio dashboard, the CMS parses the `customization` array from `storio.template.json`. If you add a `"type": "color"` field, the CMS automatically renders a color picker in the admin UI.
2. **Default Fallback Values:** The `"default"` values in this JSON file are crucial. If an admin has not set custom colors yet, the CMS uses these defaults to render your site smoothly.

---

## 2. Syncing the Manifest to the Backend (`npm run sync`)

When building a template locally, you may update default colors or add new customization fields. To notify the CMS backend about these changes, you need a sync script in your template project.

### Step A: Create `scripts/sync.js` in your template root
Create a file named `scripts/sync.js`:

```javascript
const fs = require('fs');
const path = require('path');
const http = require('http');

async function syncManifest() {
  try {
    const publicDir = path.join(__dirname, '..', 'public');
    if (!fs.existsSync(publicDir)) {
      console.error(`Error: Could not find public directory at ${publicDir}`);
      process.exit(1);
    }

    const files = fs.readdirSync(publicDir);
    const manifestFiles = files.filter(f => f.startsWith('storio.template.') && f.endsWith('.json'));

    if (manifestFiles.length === 0) {
      console.error(`Error: Could not find any storio.template*.json files in ${publicDir}`);
      process.exit(1);
    }

    for (const file of manifestFiles) {
      const manifestPath = path.join(publicDir, file);
      console.log(`Reading manifest from ${manifestPath}...`);
      const manifestContent = fs.readFileSync(manifestPath, 'utf8');
      const manifestData = JSON.parse(manifestContent);
      
      const templateId = manifestData.id;
      if (!templateId) {
        console.error(`Error: Manifest ${file} must contain an 'id' field.`);
        continue;
      }

      console.log(`Syncing template '${templateId}' to Storio CMS backend...`);
      const requestData = JSON.stringify(manifestData);

      await new Promise((resolve) => {
        const options = {
          hostname: 'localhost',
          port: 8000,
          path: '/api/v2/system/template-registry/sync-local/',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(requestData)
          }
        };

        const req = http.request(options, (res) => {
          let responseBody = '';
          res.on('data', (chunk) => { responseBody += chunk; });
          res.on('end', () => {
            if (res.statusCode >= 200 && res.statusCode < 300) {
              console.log('Success: Synced successfully.');
            } else {
              console.error(`API Error (${res.statusCode}):`, responseBody);
            }
            resolve();
          });
        });

        req.on('error', (e) => {
          console.error(`Connection Error: Could not connect to Storio CMS backend at http://localhost:8000.`);
          console.error(`Details: ${e.message}`);
          resolve();
        });

        req.write(requestData);
        req.end();
      });
    }
  } catch (error) {
    console.error('Sync failed:', error.message);
  }
}

syncManifest();
```

### Step B: Add `"sync"` to your `package.json`
In your template's `package.json`, add the script under `"scripts"`:

```json
"scripts": {
  "dev": "next dev",
  "build": "next build",
  "sync": "node scripts/sync.js"
}
```

### Step C: Execute `npm run sync`
Whenever you edit `public/storio.template.json`, run:

```bash
npm run sync
```

### What happens under the hood?
1. The script reads your local `public/storio.template.json`.
2. It sends an HTTP `POST` request to the Storio backend (`http://localhost:8000/api/v2/system/template-registry/sync-local/`).
3. The backend updates its registry with your updated manifest structure and defaults.
4. When you refresh your local Next.js standalone preview (`http://localhost:3000`), the SDK pulls the newly synced defaults, and **changes immediately reflect in your preview!**

---

## 3. Critical Top-Level Rules (`id` and `internal_proxy_url`)

> [!IMPORTANT]
> **Strict Formatting Rules:** The backend registry enforces strict naming patterns for top-level fields.

### A. The `id` Field
The template `id` must follow the format: `"template-[ID_NUMBER]-[name]"`.
- **Correct:** `"template-6-emerald"`, `"template-1-zenova"`
- **Incorrect:** `"emerald-campus"`, `"template_6"`

### B. The `internal_proxy_url` Field
Tells the Storio CMS backend where to route preview traffic to your Next.js local server:
- **Using Docker:** If Storio CMS backend runs inside Docker but your Next.js template runs locally on port 3004, set:
  `"internal_proxy_url": "http://host.docker.internal:3004"`
- **Native Local Dev:** If everything runs natively on your machine without Docker, set:
  `"internal_proxy_url": "http://localhost:3000"`

---

## 4. Rules for Writing the `customization` Schema

Each customization option in the `customization` array must include:

| Field | Type | Description | Example |
| :--- | :--- | :--- | :--- |
| `id` | `string` | Unique identifier (in `camelCase`). Used as key in React code. | `"primaryColor"` |
| `label` | `string` | Human-readable label displayed in CMS Dashboard. | `"Primary Brand Color"` |
| `type` | `string` | Control type: `"color"`, `"text"`, `"boolean"`, `"select"`, `"links"` | `"color"` |
| `default` | `any` | Default fallback value. | `"#0e704b"` |
| `options` | `array` | Required only when `type` is `"select"`. Array of `{ "label", "value" }` | `[{"label": "Dark", "value": "dark"}]` |

---

## 5. Full JSON Structure (Emerald Campus Blueprint)

Below is the **complete manifest blueprint** from Emerald Campus. You can copy this template structure for new designs:

```json
{
    "id": "template-6-emerald",
    "name": "Emerald Campus",
    "internal_proxy_url": "http://host.docker.internal:3004",
    "version": "1.0",
    "customization": {
        "colors": [
            {
                "id": "primaryColor",
                "label": "Primary Color",
                "type": "color",
                "default": "#0e704b"
            },
            {
                "id": "backgroundColor",
                "label": "Background Color",
                "type": "color",
                "default": "#f8f4e7"
            },
            {
                "id": "surfaceColor",
                "label": "Surface Color",
                "type": "color",
                "default": "#ffffff"
            },
            {
                "id": "textColor",
                "label": "Text Color",
                "type": "color",
                "default": "#3a3a41"
            },
            {
                "id": "headingColor",
                "label": "Heading Color",
                "type": "color",
                "default": "#3a3a41"
            },
            {
                "id": "footerColor",
                "label": "Footer Color",
                "type": "color",
                "default": "#101828"
            },
            {
                "id": "accentColor",
                "label": "Accent Color",
                "type": "color",
                "default": "#0e704b"
            },
            {
                "id": "buttonColor",
                "label": "Button Color",
                "type": "color",
                "default": "#0e704b"
            },
            {
                "id": "buttonTextColor",
                "label": "Button Text Color",
                "type": "color",
                "default": "#f8f4e7"
            },
            {
                "id": "buttonHoverColor",
                "label": "Button Hover Color",
                "type": "color",
                "default": "#b62309"
            },
            {
                "id": "buttonTextHoverColor",
                "label": "Button Text Hover Color",
                "type": "color",
                "default": "#f8f4e7"
            },
            {
                "id": "activeNavBgColor",
                "label": "Active Nav BG Color",
                "type": "color",
                "default": "#f0f7ef"
            },
            {
                "id": "activeNavTextColor",
                "label": "Active Nav Text Color",
                "type": "color",
                "default": "#0e704b"
            }
        ],
        "typography": [
            {
                "id": "fontFamily",
                "label": "Body Font",
                "type": "text",
                "default": "Roboto"
            }
        ],
        "layout": [
            {
                "id": "borderRadius",
                "label": "Border Radius",
                "type": "text",
                "default": "8px"
            }
        ],
        "content": [
            {
                "id": "showHero",
                "label": "Show Hero Section",
                "type": "boolean",
                "default": true
            },
            {
                "id": "heroHeadline",
                "label": "Hero Headline",
                "type": "text",
                "default": "Welcome to Emerald Campus"
            },
            {
                "id": "headerStyle",
                "label": "Header Style",
                "type": "select",
                "options": [
                    { "label": "Classic", "value": "classic" },
                    { "label": "Modern", "value": "modern" },
                    { "label": "Minimal", "value": "minimal" }
                ],
                "default": "modern"
            }
        ]
    },
    "features": [
        "notice",
        "blogs",
        "gallery",
        "faq",
        "heroSlide",
        "reels",
        "activity",
        "mediaFile",
        "careers",
        "testimonial",
        "contact",
        "staff",
        "team",
        "leadership_message",
        "important_links",
        "socialLink",
        "institution_profile",
        "accounts",
        "auth",
        "generalSettings",
        "template_customization",
        "formbuilder",
        "custom_pages",
        "promotions",
        "admission",
        "exam_results",
        "calendar_events",
        "events"
    ],
    "navigation": [
        {
            "id": "navbarLinks",
            "label": "Navigation Links",
            "type": "links",
            "default": [
                { "id": "1", "name": "Home", "href": "/" },
                {
                    "id": "2",
                    "name": "About Us",
                    "href": "/about",
                    "subLinks": [
                        { "id": "2-1", "name": "Institution Profile", "href": "/about/institution" },
                        { "id": "2-2", "name": "School Information", "href": "/about/schoolInfo" },
                        { "id": "2-3", "name": "Administrators", "href": "/about/administrator" }
                    ]
                },
                {
                    "id": "3",
                    "name": "Personnel",
                    "href": "/personnel",
                    "subLinks": [
                        { "id": "3-1", "name": "Teachers", "href": "/personnel/teachers" },
                        { "id": "3-2", "name": "Committee Members", "href": "/personnel/staff" }
                    ]
                },
                {
                    "id": "4",
                    "name": "Exam Results",
                    "href": "/examResults",
                    "subLinks": [
                        { "id": "4-1", "name": "Public Examination", "href": "/results/publicExam" },
                        { "id": "4-2", "name": "Internal School Examination", "href": "/results/schoolExam" }
                    ]
                },
                { "id": "5", "name": "Notice", "href": "/notice" },
                {
                    "id": "6",
                    "name": "Gallery",
                    "href": "/gallery",
                    "subLinks": [
                        { "id": "6-1", "name": "Photos", "href": "/gallery/photos" },
                        { "id": "6-2", "name": "Videos", "href": "/gallery/videos" }
                    ]
                },
                { "id": "7", "name": "Blog", "href": "/blog" },
                { "id": "8", "name": "Event", "href": "/event" },
                { "id": "9", "name": "Careers", "href": "/career" },
                { "id": "10", "name": "Contact", "href": "/contact" }
            ]
        }
    ]
}
```

---

## 6. Consuming Manifest Data in Code (`fetchers.ts`)

Fetch customization settings via `@storio/template-sdk` inside your server helper file:

```typescript
import { storio } from '@storio/template-sdk';
import { headers } from 'next/headers';

export async function getSchoolData() {
  const headersList = await headers();
  const rawHost = headersList.get("x-tenant-host") || headersList.get("host") || "";
  const host = rawHost.split(":")[0];
  const isStandalone = host === 'localhost' || host === '127.0.0.1';
  const tenantHost = isStandalone ? 'demo.storio.cloud' : host;

  try {
    const customJson = await storio.getCustomization(tenantHost);
    return {
      customConfig: customJson?.config || {} 
    };
  } catch (error) {
    console.error("Failed to fetch custom config:", error);
    return { customConfig: {} };
  }
}
```

---

## 7. Build and Run Commands

```bash
# 1. Start development server
npm run dev

# 2. Sync local manifest changes to backend
npm run sync

# 3. Test production build
npm run build
npm run start
```
