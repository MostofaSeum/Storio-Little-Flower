# Storio CMS Template Development Guide (v2.0)

Welcome! This guide is the definitive manual for front-end developers building high-performance, multi-tenant website templates for **Storio CMS** (such as *Emerald Campus*, *Zenova*, *CPSC*, or *Ikigai*).

Storio templates are built as **Next.js Applications** using the **App Router** (`src/app`). Templates dynamically render site settings, theme colors, navigation, notice boards, blogs, staff directories, and admission portals based on the tenant (school/institution) visiting the site.

---

## Table of Contents

1. [Project Initialization](#1-project-initialization)
2. [The Template Manifest (`storio.template.json`)](#2-the-template-manifest-storiotemplatejson)
3. [SDK Installation & Dependency Linking](#3-sdk-installation--dependency-linking)
4. [Multi-Tenant Data Architecture & `isStandalone` Mode](#4-multi-tenant-data-architecture--isstandalone-mode)
5. [The Golden Rule: Tenant Data vs. Standalone Demo Data](#5-the-golden-rule-tenant-data-vs-standalone-demo-data)
6. [Live Preview Sync (`useLayoutData` Hook)](#6-live-preview-sync-uselayoutdata-hook)
7. [Building Client Components](#7-building-client-components)
8. [Complete SDK V2 API & Endpoints Reference](#8-complete-sdk-v2-api--endpoints-reference)
9. [Testing, Simulation & Production Checklist](#9-testing-simulation--production-checklist)

---

## 1. Project Initialization

Always build Storio templates using **Next.js App Router** (`src/app`).

```bash
npx create-next-app@latest my-awesome-template
cd my-awesome-template
```

**Recommended Settings:**
- **TypeScript:** Yes (recommended for 100% type safety with `@storio/template-sdk`)
- **ESLint:** Yes
- **Tailwind CSS / Vanilla CSS:** As preferred
- **App Router:** **Yes** (Required)
- **Import Alias:** `@/*`

---

## 2. The Template Manifest (`storio.template.json`)

Every Storio template **must** contain a manifest file placed in the `public/` directory:
`public/storio.template.json`

### Why is the manifest required?
1. **CMS Registration:** When an admin selects your template, Storio CMS reads this file to register your template.
2. **Visual Customization Form:** The CMS automatically builds an interactive admin UI form based on the `customization_schema` declared in your manifest.
3. **Default Fallbacks:** The values in this file act as initial default styling before an admin overrides them.

### Example Manifest:
```json
{
  "name": "Emerald Campus",
  "slug": "emerald-campus",
  "version": "2.0.0",
  "description": "Premium educational institution template for schools and colleges.",
  "author": "BrainIcon Technology",
  "customization_schema": {
    "colors": {
      "primary": "#047857",
      "secondary": "#065f46",
      "accent": "#f59e0b",
      "background": "#ffffff",
      "text": "#1f2937"
    },
    "typography": {
      "headingFont": "Inter",
      "bodyFont": "Inter"
    },
    "features": {
      "showHeroSlider": true,
      "showNoticeTicker": true,
      "showStaffSection": true
    }
  }
}
```

---

## 3. SDK Installation & Dependency Linking

Do **NOT** write raw `fetch()` calls to fetch core CMS data. Always use the strongly-typed official `@storio/template-sdk`.

### Installing the SDK in your Template:

In your template's `package.json`, link to the SDK package:

```json
"dependencies": {
  "@storio/template-sdk": "file:../packages/template-sdk"
}
```

Then install:
```bash
npm install
```

> **Note for SDK maintainers:** If your project references `.tgz` archives (e.g. `storio-template-sdk-1.0.1.tgz`), remember to run `npm run build` and `npm pack` inside `packages/template-sdk` when editing SDK source files.

---

## 4. Multi-Tenant Data Architecture & `isStandalone` Mode

Storio CMS operates on a **multi-tenant architecture**. The SDK identifies which school/tenant is requesting data by reading the incoming domain header (`x-tenant-host` or `host`).

### Local Development vs. Production Routing

| Environment | Incoming Host Header | Tenant Resolution (`tenantHost`) | Mode |
| :--- | :--- | :--- | :--- |
| **Local Dev (`http://localhost:3000`)** | `localhost:3000` | `demo.storio.cloud` (or Demo Fallback) | **`isStandalone = true`** |
| **Live School Domain (`school.com`)** | `school.com` | `school.com` | **`isStandalone = false`** |
| **Subdomain (`greenwood.storio.cloud`)**| `greenwood.storio.cloud` | `greenwood.storio.cloud` | **`isStandalone = false`** |

---

## 5. The Golden Rule: Tenant Data vs. Standalone Demo Data

> [!CAUTION]
> **CRITICAL RULE FOR ALL DEVELOPERS:**
> Demo Data must **NEVER** be displayed on a live tenant site, even if the school's database happens to be empty. Leaking demo data onto production sites is strictly forbidden.

### Step A: Define Standalone Demo Data
Create `src/data/defaultDemoData.ts`:
```typescript
export const DEFAULT_DEMO_DATA = {
  notices: [
    {
      id: 1,
      title: "Welcome to Greenwood International School!",
      published_date: "2026-01-01",
      is_urgent: true,
      attachment_url: "#"
    }
  ],
  heroSlides: [
    {
      id: 1,
      title: "Excellence in Education",
      subtitle: "Empowering students for a brighter future.",
      image_url: "/images/demo-hero.jpg"
    }
  ]
};
```

### Step B: The Server Component Data Fetch Pattern

In your Next.js Server Page (`src/app/page.tsx`), follow this exact 4-step pattern:

```typescript
import { storio } from "@storio/template-sdk";
import { headers } from "next/headers";
import { DEFAULT_DEMO_DATA } from "@/data/defaultDemoData";
import HomePageClient from "@/components/HomePageClient";

export default async function Page() {
  // 1. RESOLVE HOST & TENANT
  const headersList = await headers();
  const rawHost = headersList.get("x-tenant-host") || headersList.get("host") || "";
  const host = rawHost.split(":")[0];

  // 2. DETERMINE STANDALONE MODE
  const isStandalone = host === 'localhost' || host === '127.0.0.1' || host === '::1';
  const tenantHost = isStandalone ? 'demo.storio.cloud' : host;

  // 3. FETCH REAL TENANT DATA VIA SDK
  let notices = [];
  try {
    notices = await storio.getNotices(tenantHost);
  } catch (err) {
    console.error("SDK Error:", err);
  }

  // 4. APPLY THE GOLDEN RULE
  // If real tenant data exists -> use real data.
  // Otherwise -> use Demo Data ONLY IF isStandalone is true; else return empty array.
  const finalNotices = (Array.isArray(notices) && notices.length > 0)
    ? notices
    : (isStandalone ? DEFAULT_DEMO_DATA.notices : []);

  return <HomePageClient notices={finalNotices} isStandalone={isStandalone} />;
}
```

---

## 6. Live Preview Sync (`useLayoutData` Hook)

When an admin customizes colors or fonts inside the Storio CMS Dashboard, the CMS embeds your template inside an `<iframe>` and transmits real-time theme overrides via `postMessage`.

Use this custom `useLayoutData` hook in your client root layout or components:

```typescript
'use client';
import { useState, useEffect } from 'react';
import { storio, StorioCustomizationResponse } from '@storio/template-sdk';

export function useLayoutData(initialConfig?: Record<string, unknown>) {
  const [customConfig, setCustomConfig] = useState<Record<string, unknown>>(
    initialConfig || {}
  );

  useEffect(() => {
    // 1. Fetch saved database overrides if not provided
    if (!initialConfig || Object.keys(initialConfig).length === 0) {
      storio.getCustomization().then((json: StorioCustomizationResponse | null) => {
        if (json?.config) {
          setCustomConfig(json.config);
        }
      });
    }

    // 2. Listen for real-time Live Preview updates from CMS Dashboard iframe
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'THEME_UPDATE') {
        const newConfig = event.data.config;
        setCustomConfig((prev) => ({
          ...prev,
          ...newConfig,
        }));
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [initialConfig]);

  return { customConfig };
}
```

---

## 7. Building Client Components

Client components receive final data from Server Components and render UI elements gracefully.

```typescript
"use client";
import React from "react";
import { StorioNotice } from "@storio/template-sdk";

interface NoticeBoardProps {
  notices: StorioNotice[];
}

export default function NoticeBoard({ notices }: NoticeBoardProps) {
  // Graceful empty state when a live site has no notices
  if (!notices || notices.length === 0) {
    return (
      <div className="p-6 text-center text-gray-500 bg-gray-50 rounded-lg">
        No announcements or notices posted at this time.
      </div>
    );
  }

  return (
    <div className="divide-y divide-gray-200">
      {notices.map((notice) => (
        <div key={notice.id} className="py-4 flex items-center justify-between">
          <div>
            <h4 className="font-semibold text-lg text-gray-900">{notice.title}</h4>
            <span className="text-sm text-gray-500">{notice.published_date}</span>
          </div>
          {notice.attachment_url && (
            <a
              href={notice.attachment_url}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 bg-emerald-600 text-white text-sm rounded hover:bg-emerald-700"
            >
              Download PDF
            </a>
          )}
        </div>
      ))}
    </div>
  );
}
```

---

## 8. Complete SDK V2 API & Endpoints Reference

The strongly-typed `@storio/template-sdk` handles caching (`revalidate: 60`), multi-tenant headers (`x-tenant-host`), and error handling automatically.

### A. Core Site & Layout Configurations
| SDK Method | HTTP / V2 Endpoint | Description | Return Type |
| :--- | :--- | :--- | :--- |
| `storio.getSettings(host?)` | `GET /api/v2/template/settings/` | General site title, logo, favicon, email, social links | `StorioSettingsResponse` |
| `storio.getCustomization(host?)` | `GET /api/v2/template/customization/` | Custom colors, fonts, and feature flags saved by admin | `StorioCustomizationResponse` |
| `storio.getNavigation(host?)` | `GET /api/v2/template/navigation/` | Header/footer menu items with sub-menus | `StorioNavigationResponse` |
| `storio.getLayout(host?)` | `GET /api/v2/template/layout/` | **Combined call** returning settings, customization, and navigation | `StorioLayoutResponse` |
| `storio.getInstitutionProfile(host?)`| `GET /api/v2/template/institution-profile/` | EIIN, school code, address, student/teacher counts, mission/vision | `StorioInstitutionProfile` |

---

### B. Core Content & CMS Sections
| SDK Method | HTTP / V2 Endpoint | Description | Return Type |
| :--- | :--- | :--- | :--- |
| `storio.getHeroSlides(host?)` | `GET /api/v2/template/hero-slides/` | Home page hero banner carousel slides | `StorioHeroSlide[]` |
| `storio.getNotices(host?)` | `GET /api/v2/template/notices/` | List of public notice announcements | `StorioNotice[]` |
| `storio.getNoticeDetail(id, host?)` | `GET /api/v2/template/notices/${id}/` | Single notice post details by ID | `StorioNotice` |
| `storio.getBlogs(host?)` | `GET /api/v2/template/blogs/` | List of published blog articles | `StorioBlogPost[]` |
| `storio.getBlogDetail(slug, host?)` | `GET /api/v2/template/blogs/${slug}/` | Single blog article post by slug | `StorioBlogPost` |
| `storio.getActivities(host?)` | `GET /api/v2/template/activities/` | Events and co-curricular activities list | `StorioActivityItem[]` |
| `storio.getActivityDetail(slug, host?)`| `GET /api/v2/template/activities/${slug}/` | Single activity details by slug | `StorioActivityItem` |
| `storio.getPageBySlug(slug, host?)` | `GET /api/v2/template/pages/by-slug/${slug}/` | Dynamic page built using CMS page builder | `StorioCustomPage` |
| `storio.getTestimonials(host?)` | `GET /api/v2/template/testimonials/` | Testimonials from students/parents | `Record<string, unknown>[]` |
| `storio.getLeadershipMessages(host?)` | `GET /api/v2/template/leadership-messages/` | Speeches/messages from Principal/Chairman | `Record<string, unknown>[]` |
| `storio.getPromotions(host?)` | `GET /api/v2/template/promotions/` | Promotional banners and cards | `StorioPromotion[]` |
| `storio.getImportantLinks(host?)` | `GET /api/v2/template/important-links/` | Quick links to external portals/boards | `StorioImportantLink[]` |
| `storio.getFaqs(host?)` | `GET /api/v2/template/faqs/` | Frequently Asked Questions | `StorioFaq[]` |
| `storio.getVideos(host?)` | `GET /api/v2/template/reels/` | Video reels and YouTube/Vimeo embeds | `StorioVideoItem[]` |
| `storio.getCalendarEvents(host?)` | `GET /api/v2/template/calendar/` | Academic calendar events & holidays | `StorioCalendarEvent[]` |
| `storio.getExamResults(host?)` | `GET /api/v2/template/exam-results/` | Public exam pass rates (Board/PSC/JSC/SSC/HSC) | `StorioExamResult[]` |

---

### C. Personnel & Gallery Media
| SDK Method | HTTP / V2 Endpoint | Description | Return Type |
| :--- | :--- | :--- | :--- |
| `storio.getStaff(host?)` | `GET /api/v2/template/staff/` | Teachers and staff directory | `StorioStaffMember[]` |
| `storio.getTeam(host?)` | `GET /api/v2/template/team/` | Managing committee & board members | `StorioStaffMember[]` |
| `storio.getGallery(host?)` | `GET /api/v2/template/gallery/` | Standalone photo gallery items | `StorioGalleryItem[]` |
| `storio.getAlbums(host?)` | `GET /api/v2/template/albums/` | Grouped photo albums with nested images | `StorioAlbum[]` |

---

### D. Careers & Recruitment
| SDK Method | HTTP / V2 Endpoint | Description | Return Type |
| :--- | :--- | :--- | :--- |
| `storio.getCareers(host?)` | `GET /api/v2/template/careers/jobs/` | Active job openings circulars | `Record<string, unknown>[]` |
| `storio.getJobDetail(slug, host?)` | `GET /api/v2/template/careers/jobs/${slug}/` | Specific job posting details & requirements | `Record<string, unknown>` |

---

### E. Education Board Integrations
| SDK Method | HTTP / V2 Endpoint | Description | Return Type |
| :--- | :--- | :--- | :--- |
| `storio.getBoardSettings(host?)` | `GET /api/v2/template/important-links/board-settings/current/` | Board integration configuration | `Record<string, unknown>` |
| `storio.getBoardNotices(host?)` | `GET /api/v2/template/board-notices/` | Notices auto-synced from National Education Board | `StorioBoardNotice[]` |

---

### F. Admission Portal & Dynamic Forms
| SDK Method | HTTP Method & V2 Endpoint | Description | Return Type |
| :--- | :--- | :--- | :--- |
| `storio.getAdmissionFormConfig(host?)` | `GET /api/v2/template/admission/form-config/current/` | Dynamic admission form fields schema | `StorioAdmissionFormConfig` |
| `storio.sendAdmissionOTP(email, host?)` | `POST /api/v2/template/admission/send-otp/` | Send verification OTP to applicant email | `StorioAdmissionOTPResponse` |
| `storio.verifyAdmissionOTP(email, code, host?)` | `POST /api/v2/template/admission/verify-otp/` | Verify applicant email OTP code | `StorioAdmissionOTPResponse` |
| `storio.submitAdmissionApplication(formData, code, host?)` | `POST /api/v2/template/admission/applications/` | Submit final admission form payload | `StorioAdmissionApplicationResponse` |
| `storio.submitContactForm(payload, host?)` | `POST /api/v2/template/contact/` | Submit public contact form message | `Record<string, unknown>` |

---

## 9. Testing, Simulation & Production Checklist

Before submitting or deploying your template, complete this verification checklist:

### 1. Standalone Development Test (`isStandalone = true`)
- Run `npm run dev` and open `http://localhost:3000`.
- Verify that `DEFAULT_DEMO_DATA` renders cleanly without errors.

### 2. Live Tenant Simulation (`isStandalone = false`)
- Add a host entry or open `http://school.localhost:3000`.
- Verify that real SDK calls execute.
- Ensure that if the database has no records, your template displays clean empty state messages rather than breaking or showing demo data.

### 3. Live Theme Preview Test
- Embed your template in an iframe and send a `THEME_UPDATE` `postMessage`.
- Ensure theme colors update dynamically without requiring a hard page refresh.

### 4. Production Build Test
- Run `npm run build`.
- Confirm there are **zero TypeScript or build errors**.
