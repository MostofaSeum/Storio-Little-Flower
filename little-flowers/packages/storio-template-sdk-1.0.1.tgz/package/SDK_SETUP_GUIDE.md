# Setup Instructions for `@storio/template-sdk`

Follow these step-by-step instructions to set up and use the `@storio/template-sdk` package in your local template branch.

---

## 1. Folder Structure Setup

Unzip/place the `template-sdk` folder inside the `packages/` directory at the root of your project:

```text
storio-cms/
└── packages/
    └── template-sdk/
        ├── dist/
        │   ├── index.js
        │   └── index.d.ts
        ├── src/
        │   └── index.ts
        ├── package.json
        ├── tsconfig.json
        └── README.md
```

---

## 2. Build the SDK

Open your terminal, navigate to the SDK folder, install dependencies, and build the TypeScript code:

```bash
cd packages/template-sdk
npm install
npm run build
```

---

## 3. Add Dependency to Your Template

1. Open your template's `package.json` file (e.g., `zenova/package.json`, `cpsc/package.json`, etc.).
2. Add `@storio/template-sdk` under `"dependencies"`:

**Option A (Folder Reference - Recommended for development):**
```json
"dependencies": {
  "@storio/template-sdk": "file:../packages/template-sdk"
}
```

**Option B (Tarball Reference):**
```json
"dependencies": {
  "@storio/template-sdk": "file:../packages/template-sdk/storio-template-sdk-1.0.1.tgz"
}
```

---

## 4. Install in Your Template

Navigate to your template directory in the terminal and run `npm install`:

```bash
cd ../../<your-template-folder>   # e.g., cd zenova or cd cpsc
npm install
```

---

## 5. How to Use in Code

Import `storio` in any Next.js Server Component or Page file:

```typescript
import { storio } from '@storio/template-sdk';

export default async function Header() {
  // 1. Fetch Layout (Site title, logo, navbar items)
  const layout = await storio.getLayout();

  // 2. Fetch Public Announcements / Notices
  const notices = await storio.getNotices();

  return (
    <header>
      <h1>{layout?.settings?.site_title || "My Storio Site"}</h1>
    </header>
  );
}
```
